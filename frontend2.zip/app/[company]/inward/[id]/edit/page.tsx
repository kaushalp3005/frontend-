"use client"

import React, { useState, useEffect, useCallback, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { SimpleDropdown } from "@/components/ui/simple-dropdown"
import { SearchableSelect } from "@/components/ui/searchable-select"
import { useItemDescriptions, useItemCategories, useSubCategories, useVendors, useCustomers } from "@/lib/hooks/useDropdownData"
import { useAuthStore } from "@/lib/stores/auth"
import { ArrowLeft, Plus, Trash2, Save, Eye, AlertCircle, Loader2, Printer, X } from "lucide-react"
import Link from "next/link"
import { useRouter, useParams } from "next/navigation"
import { format } from "date-fns"
import { dropdownApi } from "@/lib/api"
import { getInwardDetail, type InwardDetailResponse, type Company, updateInward } from "@/types/inward"
import { LabelPreview } from "@/components/ui/label-preview"
import { useToast } from "@/hooks/use-toast"

interface SubCategoryDropdownProps {
  articleId: string
  categoryId: string
  value: string
  onValueChange: (value: string) => void
  company: Company
  error?: string
  disabled?: boolean
}

interface ItemDescriptionDropdownProps {
  articleId: string
  categoryId: string
  subCategoryId: string
  value: string
  onValueChange: (value: string) => void
  company: Company
  error?: string
  updateArticle: (id: string, field: keyof Article, value: any) => void
}

// Material Type dropdown component
function MaterialTypeDropdown({
  value,
  onValueChange,
  company,
  error,
  otherValue,
  onOtherValueChange
}: {
  value: string
  onValueChange: (value: string) => void
  company: Company
  error?: string
  otherValue?: string
  onOtherValueChange?: (value: string) => void
}) {
  const [options, setOptions] = useState<Array<{value: string, label: string}>>([])
  const [loading, setLoading] = useState(false)
  const [errorState, setErrorState] = useState<string | null>(null)

  useEffect(() => {
    const fetchMaterialTypes = async () => {
      setLoading(true)
      setErrorState(null)

      try {
        console.log("=== FETCHING MATERIAL TYPES ===")
        console.log("Company:", company)

        // Call /sku/dropdown with only company param to get material_types list
        // Per API: No params → returns material_types list only
        const data = await dropdownApi.fetchDropdown({
          company,
          limit: 1000
        })

        console.log("Material Types API Response:", data)

        // Extract material types from the API response
        if (data.options?.material_types && Array.isArray(data.options.material_types) && data.options.material_types.length > 0) {
          console.log("Found material_types in API response:", data.options.material_types)
          const materialTypeOptions = data.options.material_types.map((type: string) => ({
            value: type,
            label: type
          }))
          setOptions(materialTypeOptions)
        } else {
          console.warn("No material types returned from API for company:", company)
          setOptions([])
          setErrorState("No material types available for this company.")
        }

        console.log("=== END MATERIAL TYPES FETCH ===")
      } catch (e: any) {
        console.error("Error fetching material types:", e)
        setOptions([])
        setErrorState("Failed to load material types. Please check your connection.")
      } finally {
        setLoading(false)
      }
    }

    if (company) {
      fetchMaterialTypes()
    }
  }, [company])
  
  return (
    <SearchableSelect
      value={value}
      onValueChange={onValueChange}
      placeholder="Select material type..."
      searchPlaceholder="Search material type..."
      options={options}
      loading={loading}
      error={errorState}
      disabled={false}
      className={error ? "border-red-500" : ""}
      enableOther={true}
      otherValue={otherValue}
      onOtherValueChange={onOtherValueChange}
    />
  )
}

// Item Category dropdown component
function ItemCategoryDropdown({
  value,
  onValueChange,
  company,
  materialType,
  error,
  disabled,
  otherValue,
  onOtherValueChange
}: {
  value: string
  onValueChange: (value: string) => void
  company: Company
  materialType?: string
  error?: string
  disabled?: boolean
  otherValue?: string
  onOtherValueChange?: (value: string) => void
}) {
  const itemCategoriesHook = useItemCategories({ company, material_type: materialType })

  return (
    <SearchableSelect
      value={value}
      onValueChange={onValueChange}
      placeholder="Select category..."
      searchPlaceholder="Search category..."
      options={itemCategoriesHook.options}
      loading={itemCategoriesHook.loading}
      error={itemCategoriesHook.error}
      disabled={disabled || !materialType}
      className={error ? "border-red-500" : ""}
      onSearchChange={itemCategoriesHook.search}
      enableOther={true}
      otherValue={otherValue}
      onOtherValueChange={onOtherValueChange}
    />
  )
}

function SubCategoryDropdown({ articleId, categoryId, value, onValueChange, company, error, disabled, materialType, otherValue, onOtherValueChange }: SubCategoryDropdownProps & { materialType?: string; otherValue?: string; onOtherValueChange?: (value: string) => void }) {
  const subCategoriesHook = useSubCategories(categoryId, { company, material_type: materialType })

  return (
    <SearchableSelect
      value={value}
      onValueChange={onValueChange}
      placeholder="Select sub category..."
      searchPlaceholder="Search sub category..."
      options={subCategoriesHook.options}
      loading={subCategoriesHook.loading}
      error={subCategoriesHook.error}
      disabled={disabled || !categoryId}
      className={error ? "border-red-500" : ""}
      onSearchChange={subCategoriesHook.search}
      enableOther={true}
      otherValue={otherValue}
      onOtherValueChange={onOtherValueChange}
    />
  )
}

function ItemDescriptionDropdown({
  articleId,
  categoryId,
  subCategoryId,
  materialType,
  value,
  onValueChange,
  company,
  error,
  updateArticle,
  disabled,
  otherValue,
  onOtherValueChange
}: ItemDescriptionDropdownProps & { materialType: string; disabled?: boolean; otherValue?: string; onOtherValueChange?: (value: string) => void }) {
  const itemDescriptionsHook = useItemDescriptions({ company, material_type: materialType, item_category: categoryId, sub_category: subCategoryId })
  
  const handleValueChange = async (selectedValue: string) => {
    // Find the selected option to get the label
    const selectedOption = itemDescriptionsHook.options.find(option => option.value === selectedValue)
    if (selectedOption) {
      // Call the parent's onValueChange first to update the item_description
      onValueChange(selectedValue)

      // Reset SKU ID while fetching
      updateArticle(articleId, "sku_id", null)

      // Skip SKU lookup for "other" items - they don't have a real SKU in the database
      const isOtherItem = selectedOption.label.toLowerCase() === 'other'
      if (isOtherItem) {
        console.log(`Skipping SKU lookup for "other" item description`)
        // SKU ID stays null for "other" items - this is expected
      } else {
        // ✅ Directly call the statically imported API (typed)
        try {
          const skuResponse = await dropdownApi.fetchSkuId({
            company,
            item_description: selectedOption.label,
            item_category: categoryId,
            sub_category: subCategoryId,
            material_type: materialType
          })

          // Extract SKU ID from various possible response formats
          const skuId: number | undefined = Number(
            skuResponse?.sku_id ??
            skuResponse?.id ??
            skuResponse?.ID ??
            skuResponse?.SKU_ID
          )

          if (!skuId || Number.isNaN(skuId) || skuId <= 0) {
            throw new Error("No valid sku_id returned from API")
          }

          // Update sku_id with the real database ID
          updateArticle(articleId, "sku_id", skuId)

          // Extract and update material_type from the new payload structure
          const responseMaterialType = skuResponse?.material_type
          if (responseMaterialType) {
            updateArticle(articleId, "material_type", responseMaterialType.toUpperCase())
          }
        } catch (err) {
          console.error("Error fetching SKU ID:", err)
          // Show error to user but don't block form
          alert(`Warning: Could not fetch SKU ID for "${selectedOption.label}". Please ensure this item exists in the database.`)
          // Set SKU ID to null - will be resolved at submit time
          updateArticle(articleId, "sku_id", null)
        }
      }
    }

    onValueChange(selectedValue)
  }

  return (
    <SearchableSelect
      value={value}
      onValueChange={handleValueChange}
      placeholder="Select item description..."
      searchPlaceholder="Search item description..."
      options={itemDescriptionsHook.options}
      loading={itemDescriptionsHook.loading}
      error={itemDescriptionsHook.error}
      disabled={disabled || !categoryId || !subCategoryId}
      className={error ? "border-red-500" : ""}
      onSearchChange={itemDescriptionsHook.search}
      enableOther={true}
      otherValue={otherValue}
      onOtherValueChange={onOtherValueChange}
    />
  )
}

interface Article {
  id: string
  sku_id?: number | null
  material_type: string
  item_category: string
  sub_category: string
  item_description: string
  quantity_units: number
  packaging_type: number
  uom: string
  net_weight: number
  total_weight: number
  batch_number: string
  lot_number: string
  manufacturing_date: string
  expiry_date: string
  import_date: string
  unit_rate: number
  total_amount: number
  tax_amount: number
  discount_amount: number
  currency: string
  // Issuance fields
  issuance_date: string
  job_card_no: string
  issuance_quantity: number
  // Custom text fields for "other" option
  material_type_other?: string
  item_category_other?: string
  sub_category_other?: string
  item_description_other?: string
}

interface Box {
  id: string
  box_number: number
  article: string
  net_weight: number
  gross_weight: number
  lot_number?: string
  count: number
}

export default function EditInwardPage() {
  const params = useParams()
  const company = params.company as string
  const transactionId = params.id as string
  const router = useRouter()
  const { currentCompany } = useAuthStore()
  const { toast } = useToast()

  const vendorsHook = useVendors({ company: company as Company })
  const customersHook = useCustomers({ company: company as Company })

  // Search state for vendor and customer dropdowns
  const [vendorSearch, setVendorSearch] = useState("")
  const [customerSearch, setCustomerSearch] = useState("")

  // Display state for quantity fields to allow decimal input
  const [grnQuantityDisplay, setGrnQuantityDisplay] = useState("")
  const [receivedQuantityDisplay, setReceivedQuantityDisplay] = useState("")
  
  // Display state for issuance quantities to allow decimal input
  const [issuanceQuantityDisplays, setIssuanceQuantityDisplays] = useState<Record<string, string>>({})

  // Update vendor search when search query changes
  useEffect(() => {
    if (vendorsHook.search) {
      vendorsHook.search(vendorSearch)
    }
  }, [vendorSearch, vendorsHook.search])

  // Update customer search when search query changes
  useEffect(() => {
    if (customersHook.search) {
      customersHook.search(customerSearch)
    }
  }, [customerSearch, customersHook.search])

  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [originalData, setOriginalData] = useState<InwardDetailResponse | null>(null)

  const [formData, setFormData] = useState({
    company,
    transaction_no: "",
    entry_date: "",
    vehicle_number: "",
    transporter_name: "",
    lr_number: "",
    vendor_supplier_name: "",
    customer_party_name: "",
    // Custom vendor fields when "Other" is selected
    custom_vendor_name: "",
    // Custom customer fields when "Other" is selected
    custom_customer_name: "",
    // Custom approval authority field when "Other" is selected
    custom_approval_authority: "",
    source_location: "",
    destination_location: "",
    challan_number: "",
    invoice_number: "",
    po_number: "",
    grn_number: "",
    grn_quantity: 0,
    system_grn_date: "",
    purchase_by: "",
    bill_submitted_to_account: false,
    grn_remark: "",
    process_type: "",
    service_remarks: "",
    service_invoice_number: "",
    dn_number: "",
    approval_authority: "",
    received_quantity: 0,
    return_reason_remark: "",
    remark: "",
  })

  // Initialize display values when form data changes
  useEffect(() => {
    setGrnQuantityDisplay(formData.grn_quantity.toString())
  }, [formData.grn_quantity])

  useEffect(() => {
    setReceivedQuantityDisplay(formData.received_quantity.toString())
  }, [formData.received_quantity])


  const [articles, setArticles] = useState<Article[]>([])

  // Initialize issuance quantity displays when articles change
  useEffect(() => {
    const newDisplays: Record<string, string> = {}
    articles.forEach(article => {
      newDisplays[article.id] = article.issuance_quantity.toString()
    })
    setIssuanceQuantityDisplays(newDisplays)
  }, [articles])

  const [boxes, setBoxes] = useState<Box[]>([])
  const [errors, setErrors] = useState<Record<string, string>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [printingBoxes, setPrintingBoxes] = useState<Set<number>>(new Set())
  const [quantityWarnings, setQuantityWarnings] = useState<Record<string, string>>({})
  
  // Ref to prevent infinite loop in useEffect
  const isUpdatingArticles = useRef(false)
  const prevArticlesRef = useRef<Article[]>(articles)

  // Update article net_weight and total_weight based on box management summary
  // Debounced to prevent lag when typing in box fields
  useEffect(() => {
    if (boxes.length === 0) return
    if (isUpdatingArticles.current) return // Prevent infinite loop
    
    // Only update articles if boxes have meaningful weights
    const hasValidWeights = boxes.some(box => box.net_weight > 0 || box.gross_weight > 0)
    if (!hasValidWeights) return
    
    // Debounce the calculation to avoid lag when typing
    const timeoutId = setTimeout(() => {
      if (isUpdatingArticles.current) return
      
      isUpdatingArticles.current = true
      
      setArticles(prevArticles => {
        const updatedArticles = prevArticles.map(article => {
          // Find all boxes for this article
          const articleBoxes = boxes.filter(box => box.article === article.item_description)
          
          if (articleBoxes.length > 0) {
            const totalNetWeight = articleBoxes.reduce((sum, box) => sum + box.net_weight, 0)
            const totalGrossWeight = articleBoxes.reduce((sum, box) => sum + box.gross_weight, 0)
            
            // Round to 3 decimal places
            const roundedNetWeight = Math.round(totalNetWeight * 1000) / 1000
            const roundedGrossWeight = Math.round(totalGrossWeight * 1000) / 1000
            
            // Only update if the values have actually changed to prevent infinite loops
            if (Math.abs(article.net_weight - roundedNetWeight) > 0.001 || 
                Math.abs(article.total_weight - roundedGrossWeight) > 0.001) {
              return {
                ...article,
                net_weight: roundedNetWeight,
                total_weight: roundedGrossWeight
              }
            }
          }
          
          return article
        })
        
        isUpdatingArticles.current = false
        return updatedArticles
      })
    }, 300) // 300ms debounce delay
    
    return () => clearTimeout(timeoutId)
  }, [boxes])

  const generateBatchNumber = () => {
    const now = new Date()
    const year = now.getFullYear()
    const month = String(now.getMonth() + 1).padStart(2, "0")
    const day = String(now.getDate()).padStart(2, "0")
    const hour = String(now.getHours()).padStart(2, "0")
    const minute = String(now.getMinutes()).padStart(2, "0")
    const second = String(now.getSeconds()).padStart(2, "0")
    return `BT-${year}${month}${day}${hour}${minute}${second}-001`
  }

  const generateBoxes = (articlesToUse?: Article[], forceRecalculate: boolean = false, articleId?: string) => {
    const articlesForGeneration = articlesToUse || articles
    const newBoxes: Box[] = []
    let boxCounter = 1
    const today = new Date()
    const dateString = today.getFullYear().toString().slice(-2) +
      (today.getMonth() + 1).toString().padStart(2, '0') +
      today.getDate().toString().padStart(2, '0')

    // If articleId is specified, preserve boxes for other articles
    const targetArticle = articleId ? articlesForGeneration.find(a => a.id === articleId) : null
    
    // First, preserve boxes for articles that are NOT being regenerated
    if (articleId && targetArticle) {
      // Keep boxes for all articles except the one being regenerated
      const preservedBoxes = boxes.filter(b => b.article !== targetArticle.item_description)
      newBoxes.push(...preservedBoxes)
      // Update boxCounter to be after the highest box number in preserved boxes
      if (preservedBoxes.length > 0) {
        boxCounter = Math.max(...preservedBoxes.map(b => b.box_number)) + 1
      }
    }

    articlesForGeneration.forEach((article) => {
      // If articleId is specified, only process that article
      if (articleId && article.id !== articleId) {
        return
      }

      // Generate boxes if UOM is BOX, CARTON, or BAG (even if quantity is 0)
      const uomUpper = article.uom?.toUpperCase() || ""
      if (uomUpper === "BOX" || uomUpper === "CARTON" || uomUpper === "BAG") {
        const cleanItemDescription = (article.item_description || `Article${article.id}`)
          .replace(/[^a-zA-Z0-9]/g, '')
          .toUpperCase()
          .substring(0, 10)

        // Get existing boxes for this article from current boxes state
        const existingArticleBoxes = boxes.filter(b => b.article === article.item_description)

        // Determine number of boxes to generate:
        // - If quantity > 0: use quantity_units
        // - If quantity = 0: preserve all existing boxes (don't reduce)
        // - If no existing boxes and quantity = 0: create 0 boxes
        let numBoxes: number
        if (article.quantity_units > 0) {
          numBoxes = article.quantity_units
        } else if (existingArticleBoxes.length > 0) {
          // Quantity is 0 but we have existing boxes - preserve them all
          numBoxes = existingArticleBoxes.length
        } else {
          // Quantity is 0 and no existing boxes - create 0 boxes
          numBoxes = 0
        }

        for (let i = 0; i < numBoxes; i++) {
          // Try to preserve existing box data - match by index within the article's boxes
          const existingBox = existingArticleBoxes[i]

          // Only recalculate weights if forced or if it's a new box
          const shouldUseExistingWeights = existingBox && !forceRecalculate

          newBoxes.push({
            id: existingBox?.id || `${dateString}${cleanItemDescription}${boxCounter}`,
            box_number: boxCounter,
            article: article.item_description || `Article ${article.id}`,
            net_weight: existingBox?.net_weight || 0, // Always start with 0 or preserve existing manual value
            gross_weight: existingBox?.gross_weight || 0, // Always start with 0 or preserve existing manual value
            lot_number: article.lot_number || existingBox?.lot_number || "",
            count: existingBox?.count || 1,
          })
          boxCounter++
        }
      }
    })
    setBoxes(newBoxes)
  }

  const validateForm = () => {
    const newErrors: Record<string, string> = {}
    if (!formData.vehicle_number.trim()) newErrors.vehicle_number = "Vehicle number is required"
    if (!formData.transporter_name.trim()) newErrors.transporter_name = "Transporter name is required"
    if (!formData.vendor_supplier_name.trim()) newErrors.vendor_supplier_name = "Vendor/Supplier name is required"
    if (!formData.customer_party_name.trim()) newErrors.customer_party_name = "Customer/Party name is required"
    if (!formData.purchase_by.trim()) newErrors.purchase_by = "Purchase By is required"
    if (!formData.approval_authority.trim()) newErrors.approval_authority = "Approval Authority is required"
    
    // Validate custom vendor fields when "Other" is selected
    if (formData.vendor_supplier_name === "Other") {
      if (!formData.custom_vendor_name.trim()) newErrors.custom_vendor_name = "Custom vendor name is required"
    }
    
    // Validate custom customer fields when "Other" is selected
    if (formData.customer_party_name === "Other") {
      if (!formData.custom_customer_name.trim()) newErrors.custom_customer_name = "Custom customer name is required"
    }
    
    // Validate custom approval authority field when "Other" is selected
    if (formData.approval_authority === "Other") {
      if (!formData.custom_approval_authority.trim()) newErrors.custom_approval_authority = "Custom approval authority name is required"
    }
    
    if (formData.grn_quantity < 0) newErrors.grn_quantity = "GRN quantity cannot be negative"
    if (formData.received_quantity < 0) newErrors.received_quantity = "Received quantity cannot be negative"

    articles.forEach((article, index) => {
      if (!article.item_category.trim()) newErrors[`article_${index}_category`] = "Item category is required"
      if (!article.sub_category.trim()) newErrors[`article_${index}_sub_category`] = "Sub category is required"
      if (!article.item_description.trim()) newErrors[`article_${index}_description`] = "Item description is required"
      if (!article.quantity_units || article.quantity_units <= 0) newErrors[`article_${index}_quantity`] = "Quantity must be greater than 0"
      if (article.uom === "") newErrors[`article_${index}_uom`] = "UOM is required"
      if (article.net_weight <= 0) newErrors[`article_${index}_net_weight`] = "Net weight must be greater than 0"
      if (article.total_weight <= 0) newErrors[`article_${index}_total_weight`] = "Total weight must be greater than 0"
      if (article.total_weight <= article.net_weight) newErrors[`article_${index}_total_weight`] = "Gross weight must be greater than net weight"
      // if (article.unit_rate <= 0) newErrors[`article_${index}_unit_rate`] = "Unit rate must be greater than 0"
      // if (article.tax_amount < 0) newErrors[`article_${index}_tax_amount`] = "Tax amount cannot be negative"
      // if (article.discount_amount < 0) newErrors[`article_${index}_discount_amount`] = "Discount amount cannot be negative"
    })

    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }

  const addArticle = () => {
    const newArticle: Article = {
      id: Date.now().toString(),
      sku_id: null,
      material_type: "",
      item_category: "",
      sub_category: "",
      item_description: "",
      quantity_units: 0,
      packaging_type: 0,
      uom: "",
      net_weight: 0,
      total_weight: 0,
      batch_number: generateBatchNumber(),
      lot_number: "",
      manufacturing_date: "",
      expiry_date: "",
      import_date: "",
      unit_rate: 0,
      total_amount: 0,
      tax_amount: 0,
      discount_amount: 0,
      currency: "INR",
      // Issuance fields
      issuance_date: "",
      job_card_no: "",
      issuance_quantity: 0,
      // Custom text fields for "other" option
      material_type_other: "",
      item_category_other: "",
      sub_category_other: "",
      item_description_other: "",
    }
    const updatedArticles = [...articles, newArticle]
    setArticles(updatedArticles)
    // Don't regenerate boxes when adding a new article - let useEffect handle it
    // generateBoxes(updatedArticles)
  }

  const removeArticle = (id: string) => {
    if (articles.length > 1) {
      const articleToRemove = articles.find(a => a.id === id)
      const updatedArticles = articles.filter((article) => article.id !== id)
      setArticles(updatedArticles)
      // Remove boxes for the deleted article, preserve others
      if (articleToRemove) {
        setBoxes(boxes.filter(box => box.article !== articleToRemove.item_description))
      }
      // Regenerate boxes for remaining articles to ensure proper numbering
      generateBoxes(updatedArticles)
    }
  }

  const updateArticle = (id: string, field: keyof Article, value: any) => {
    const updatedArticles = articles.map((article) => {
      if (article.id === id) {
        const updatedArticle = { ...article, [field]: value }
        // If material type changes, clear all dependent fields
        if (field === "material_type") {
          updatedArticle.item_category = ""
          updatedArticle.sub_category = ""
          updatedArticle.item_description = ""
          updatedArticle.sku_id = null
        }
        // If category or sub category changes, nuke stale item selection + sku
        if (field === "item_category") {
          updatedArticle.sub_category = ""
          updatedArticle.item_description = ""
          updatedArticle.sku_id = null
        }
        if (field === "sub_category") {
          updatedArticle.item_description = ""
          updatedArticle.sku_id = null
        }
        if (field === "unit_rate" || field === "quantity_units") {
          updatedArticle.total_amount = (Number(updatedArticle.unit_rate) || 0) * (Number(updatedArticle.quantity_units) || 0)
        }

        // Handle quantity warning when set to 0
        if (field === "quantity_units") {
          if (Number(value) === 0 && (updatedArticle.uom === "BOX" || updatedArticle.uom === "CARTON" || updatedArticle.uom === "BAG")) {
            setQuantityWarnings(prev => ({
              ...prev,
              [id]: "Warning: Setting quantity to 0 will preserve existing boxes but they won't be updated with new weight distributions."
            }))
          } else {
            setQuantityWarnings(prev => {
              const newWarnings = { ...prev }
              delete newWarnings[id]
              return newWarnings
            })
          }
        }

        return updatedArticle
      }
      return article
    })

    setArticles(updatedArticles)

    if (field === "item_description" || field === "lot_number") {
      if (field === "item_description") {
        generateBoxes(updatedArticles, true, id) // Force recalculate when item changes, only for this article
      } else {
        setBoxes((currentBoxes) =>
          currentBoxes.map((box) => {
            const article = updatedArticles.find(art => art.id === id)
            if (article && box.article === article.item_description) {
              return { ...box, lot_number: value }
            }
            return box
          })
        )
      }
    } else if (field === "quantity_units") {
      // When quantity changes to 0, don't regenerate boxes - preserve existing ones
      // Only regenerate boxes if quantity is greater than 0
      if (Number(value) > 0) {
        generateBoxes(updatedArticles, false, id) // Only regenerate boxes for this article
      }
      // If quantity is 0, we do nothing - existing boxes are preserved
    } else if (field === "net_weight" || field === "total_weight") {
      // Don't recalculate box weights when article weights change
      // User wants to manually set each box weight independently
    } else if (field === "uom") {
      generateBoxes(updatedArticles, true, id) // Force recalculate when UOM changes, only for this article
    }
  }

  const updateBox = useCallback((boxId: string, field: keyof Box, value: any) => {
    if (field === "net_weight" || field === "gross_weight" || field === "count") {
      // Default empty weight values to 0
      let finalValue = value
      if (field === "net_weight" || field === "gross_weight") {
        finalValue = value === "" || value === null || value === undefined ? 0 : Number(value)
      }
      // Use functional update to avoid stale closure issues
      setBoxes(prevBoxes => prevBoxes.map((box) => (box.id === boxId ? { ...box, [field]: finalValue } : box)))
    }
  }, [])

  const getArticleBoxStats = () => {
    const stats: Record<string, { boxes: number; netWeight: number; grossWeight: number; articleName: string }> = {}
    boxes.forEach((box) => {
      const article = articles.find(art => art.item_description === box.article)
      if (article) {
        const articleId = article.id
        if (!stats[articleId]) {
          stats[articleId] = {
            boxes: 0,
            netWeight: 0,
            grossWeight: 0,
            articleName: article.item_description || `Article ${articleId}`,
          }
        }
        stats[articleId].boxes += 1
        stats[articleId].netWeight += box.net_weight
        stats[articleId].grossWeight += box.gross_weight
      }
    })
    return stats
  }

  const handlePrintBox = async (box: Box) => {
    // Mark this box as being printed
    setPrintingBoxes(prev => new Set(prev).add(box.box_number))

    try {
      console.log("Printing box:", box)
      
      // Find the article associated with this box
      const associatedArticle = articles.find(art => art.item_description === box.article)
      if (!associatedArticle) {
        alert("Error: Could not find associated article for this box")
        return
      }

      // Dynamically import QR utilities
      const { generateSimplifiedQRData } = await import('@/lib/utils/qr')
      const QRCode = (await import('qrcode')).default

      // Prepare QR payload
      const qrPayload = {
        company: company,
        entry_date: formData.entry_date,
        vendor_name: formData.vendor_supplier_name || '',
        customer_name: formData.customer_party_name || '',
        item_description: associatedArticle.item_description,
        net_weight: box.net_weight,
        total_weight: box.gross_weight,
        batch_number: associatedArticle.batch_number || '',
        lot_number: box.lot_number || associatedArticle.lot_number || '',
        box_number: box.box_number,
        manufacturing_date: associatedArticle.manufacturing_date,
        expiry_date: associatedArticle.expiry_date,
        transaction_no: formData.transaction_no,
        sku_id: associatedArticle.sku_id || 0,
        approval_authority: formData.approval_authority
      }

      // Generate QR data string
      const qrDataString = generateSimplifiedQRData(qrPayload)

      // Generate QR code as Data URL
      const qrCodeDataURL = await QRCode.toDataURL(qrDataString, {
        width: 170,
        margin: 1,
        errorCorrectionLevel: 'M'
      })

      // Format dates
      const formatDate = (dateString?: string) => {
        if (!dateString) return ''
        try {
          return new Date(dateString).toLocaleDateString('en-GB', {
            day: '2-digit',
            month: '2-digit',
            year: '2-digit'
          })
        } catch {
          return ''
        }
      }

      // Create a hidden iframe for printing
      const iframe = document.createElement('iframe')
      iframe.style.position = 'absolute'
      iframe.style.width = '0'
      iframe.style.height = '0'
      iframe.style.border = 'none'
      iframe.style.visibility = 'hidden'
      document.body.appendChild(iframe)

      const iframeDoc = iframe.contentWindow?.document
      if (iframeDoc) {
        iframeDoc.open()
        iframeDoc.write(`
          <!DOCTYPE html>
          <html>
            <head>
              <title>Print Label - Box ${box.box_number}</title>
              <style>
                * {
                  margin: 0;
                  padding: 0;
                  box-sizing: border-box;
                }
                html, body {
                  width: 4in;
                  height: 2in;
                  margin: 0;
                  padding: 0;
                  overflow: hidden;
                  font-family: Arial, sans-serif;
                  background: white;
                  position: relative;
                }
                .label-container {
                  position: absolute;
                  top: 0;
                  left: 0;
                  width: 4in;
                  height: 2in;
                  background: white;
                  border: 1px solid #000;
                  display: flex;
                  margin: 0;
                  padding: 0;
                  box-sizing: border-box;
                }
                .qr-section {
                  width: 2in;
                  height: 2in;
                  display: flex;
                  align-items: center;
                  justify-content: center;
                  padding: 0.1in;
                }
                .qr-section img {
                  width: 1.7in;
                  height: 1.7in;
                }
                .info-section {
                  position: relative;
                  width: 2in;
                  height: 2in;
                  padding: 0.08in;
                  font-size: 8pt;
                  line-height: 1.1;
                  overflow: hidden;
                }
                .info-section-content {
                  position: absolute;
                  top: 50%;
                  left: 0.08in;
                  right: 0.08in;
                  transform: translateY(-50%);
                  display: flex;
                  flex-direction: column;
                  gap: 0.05in;
                }
                .company-info {
                  font-weight: bold;
                  font-size: 9pt;
                  margin-bottom: 0;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                }
                .transaction-info {
                  font-size: 7pt;
                  font-family: monospace;
                  margin-bottom: 0;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                }
                .item-description {
                  font-weight: bold;
                  font-size: 7.5pt;
                  line-height: 1.1;
                  max-height: 0.5in;
                  overflow: hidden;
                  display: -webkit-box;
                  -webkit-line-clamp: 2;
                  -webkit-box-orient: vertical;
                  word-wrap: break-word;
                  word-break: break-word;
                  margin-bottom: 0;
                }
                .details {
                  font-size: 7.5pt;
                  line-height: 1.15;
                  flex: 1;
                  overflow: hidden;
                }
                .details-row {
                  margin-bottom: 0;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                }
                .batch-info {
                  font-size: 7pt;
                  font-family: monospace;
                  margin-bottom: 0;
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                  max-width: 1.84in;
                  display: block;
                }
                .exp-date {
                  color: #d00;
                  font-weight: bold;
                }

                @media print {
                  @page {
                    size: 4in 2in;
                    margin: 0;
                    padding: 0;
                  }
                  * {
                    margin: 0 !important;
                    padding: 0 !important;
                    page-break-after: avoid !important;
                    page-break-before: avoid !important;
                    page-break-inside: avoid !important;
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                    orphans: 1 !important;
                    widows: 1 !important;
                  }
                  html {
                    width: 4in !important;
                    height: 2in !important;
                    max-height: 2in !important;
                    min-height: 2in !important;
                    overflow: hidden !important;
                    page-break-after: avoid !important;
                  }
                  body {
                    position: relative !important;
                    width: 4in !important;
                    height: 2in !important;
                    max-height: 2in !important;
                    min-height: 2in !important;
                    margin: 0 !important;
                    padding: 0 !important;
                    background: white;
                    overflow: hidden !important;
                    page-break-after: avoid !important;
                  }
                  .label-container {
                    position: absolute !important;
                    top: 0 !important;
                    left: 0 !important;
                    width: 4in !important;
                    height: 2in !important;
                    max-height: 2in !important;
                    min-height: 2in !important;
                    border: 1px solid #000 !important;
                    margin: 0 !important;
                    padding: 0 !important;
                    box-sizing: border-box !important;
                    page-break-after: avoid !important;
                    page-break-inside: avoid !important;
                  }
                  script {
                    display: none !important;
                  }
                }
              </style>
            </head>
            <body>
              <div class="label-container">
                <div class="qr-section">
                  <img src="${qrCodeDataURL}" alt="QR Code" />
                </div>
                <div class="info-section">
                  <div class="info-section-content">
                    <div>
                      <div class="company-info">${qrPayload.company}</div>
                      <div class="transaction-info">${qrPayload.transaction_no}</div>
                    </div>
                    <div class="item-description">${qrPayload.item_description}</div>
                    <div class="details">
                      <div class="details-row">
                        <span>Box #${qrPayload.box_number}</span>
                      </div>
                      <div class="details-row">
                        <span>Net Wt: ${qrPayload.net_weight}kg</span>
                      </div>
                      <div class="details-row">
                        <span>Gross Wt: ${qrPayload.total_weight}kg</span>
                      </div>
                      <div class="details-row">
                        <span>Entry: ${formatDate(qrPayload.entry_date)}</span>
                      </div>
                      ${qrPayload.expiry_date ? `
                      <div class="details-row exp-date">
                        <span>Exp: ${formatDate(qrPayload.expiry_date)}</span>
                      </div>
                      ` : ''}
                      ${qrPayload.lot_number ? `
                      <div class="batch-info">Lot: ${qrPayload.lot_number.length > 20 ? qrPayload.lot_number.substring(0, 20) + '...' : qrPayload.lot_number}</div>
                      ` : ''}
                      ${qrPayload.customer_name ? `
                      <div class="details-row">
                        <span>Cust: ${qrPayload.customer_name.length > 20 ? qrPayload.customer_name.substring(0, 20) + '...' : qrPayload.customer_name}</span>
                      </div>
                      ` : ''}
                    </div>
                  </div>
                </div>
              </div>
              <script>
                // Remove any extra content that might cause blank pages
                document.addEventListener('DOMContentLoaded', function() {
                  // Remove any empty divs or extra elements
                  const body = document.body;
                  const children = Array.from(body.children);
                  children.forEach(child => {
                    if (child.classList.contains('label-container') === false && 
                        child.tagName !== 'SCRIPT') {
                      body.removeChild(child);
                    }
                  });
                });

                // Auto-trigger browser print dialog
                window.onload = function() {
                  setTimeout(() => {
                    window.print();
                    // Close iframe after printing or canceling
                    window.onafterprint = function() {
                      window.parent.postMessage('print-complete', '*');
                    };
                  }, 300);
                };
              </script>
            </body>
          </html>
        `)
        iframeDoc.close()

        // Listen for print completion to remove iframe
        const handleMessage = (event: MessageEvent) => {
          if (event.data === 'print-complete') {
            document.body.removeChild(iframe)
            window.removeEventListener('message', handleMessage)
          }
        }
        window.addEventListener('message', handleMessage)

        // Fallback cleanup after 30 seconds
        setTimeout(() => {
          if (document.body.contains(iframe)) {
            document.body.removeChild(iframe)
            window.removeEventListener('message', handleMessage)
          }
        }, 30000)
      }

      console.log(`Box ${box.box_number} label sent to print`)

    } catch (error) {
      console.error("Error processing box print:", error)
      alert(`Error: ${error instanceof Error ? error.message : 'Failed to process box print'}`)
    } finally {
      setTimeout(() => {
        setPrintingBoxes(prev => {
          const newSet = new Set(prev)
          newSet.delete(box.box_number)
          return newSet
        })
      }, 1000)
    }
  }

  const handleDeleteBox = (box: Box) => {
    // Find the article associated with this box
    const associatedArticle = articles.find(art => art.item_description === box.article)
    
    if (!associatedArticle) {
      alert("Error: Could not find associated article for this box")
      return
    }

    // Confirm deletion
    if (!confirm(`Are you sure you want to remove Box #${box.box_number}? This will also decrement the quantity by 1.`)) {
      return
    }

    // Remove the box from boxes array
    const updatedBoxes = boxes.filter(b => b.id !== box.id)
    setBoxes(updatedBoxes)

    // Decrement the quantity_units of the associated article by 1
    const updatedArticles = articles.map(article => {
      if (article.id === associatedArticle.id) {
        const newQuantity = Math.max(0, article.quantity_units - 1) // Prevent negative quantities
        return {
          ...article,
          quantity_units: newQuantity,
          total_amount: (Number(article.unit_rate) || 0) * newQuantity // Recalculate total amount
        }
      }
      return article
    })
    setArticles(updatedArticles)

    // Show success message
    console.log(`Box #${box.box_number} deleted successfully. Article quantity decremented.`)
  }

  // --- Helper: check if an article has "other" in any dropdown field ---
  const isOtherItem = (article: Article): boolean => {
    const fieldsToCheck = [
      article.item_description,
      article.item_category,
      article.sub_category,
      article.material_type
    ]
    return fieldsToCheck.some(
      field => typeof field === 'string' && field.toLowerCase() === 'other'
    )
  }

  // --- Helper: ensure a valid sku_id for an article (used just before submit) ---
  // Returns null for "other" items that don't have a real SKU
  const resolveSkuId = async (article: Article): Promise<number | null> => {
    // Skip SKU lookup for "other" items - they don't have a real SKU in the database
    if (isOtherItem(article)) {
      console.log(`Skipping SKU lookup for "other" item: ${article.item_description}`)
      return null
    }

    if (article.sku_id && article.sku_id > 0) {
      return article.sku_id
    }

    if (!article.item_description || !article.item_category || !article.sub_category) {
      throw new Error(`Missing required fields for SKU resolution: ${article.item_description || "Unnamed item"}`)
    }

    try {
      // ✅ Direct typed call, no dynamic import
      const res = await dropdownApi.fetchSkuId({
        company: company as Company,
        item_description: article.item_description,
        item_category: article.item_category,
        sub_category: article.sub_category,
      })

      const sku = Number(
        res?.sku_id ??
        res?.id ??
        res?.ID ??
        res?.SKU_ID
      )

      if (!Number.isFinite(sku) || sku <= 0) {
        throw new Error(`Invalid SKU ID returned: ${sku}`)
      }

      return sku
    } catch (error) {
      console.error("Error resolving SKU ID:", error)
      throw new Error(`Could not resolve SKU ID for "${article.item_description}": ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  const handleSave = async () => {
    const isValid = validateForm()
    if (!isValid) {
      return
    }

    setIsSubmitting(true)
    try {
      // Resolve all missing SKU IDs just-in-time to avoid race with async dropdown fetch
      const resolvedArticles = await Promise.all(
        articles.map(async (a) => {
          const sku = await resolveSkuId(a)
          return { ...a, sku_id: sku }
        })
      )

      // Persist resolved sku in state (optional but nice for consistency)
      setArticles(resolvedArticles)

      const submissionData = {
        company: company as Company,
        transaction: {
          transaction_no: formData.transaction_no,
          entry_date: formData.entry_date,
          vehicle_number: formData.vehicle_number,
          transporter_name: formData.transporter_name,
          lr_number: formData.lr_number,
          vendor_supplier_name: formData.vendor_supplier_name === "Other" ? formData.custom_vendor_name : formData.vendor_supplier_name,
          customer_party_name: formData.customer_party_name === "Other" ? formData.custom_customer_name : formData.customer_party_name,
          source_location: formData.source_location,
          destination_location: formData.destination_location,
          challan_number: formData.challan_number,
          invoice_number: formData.invoice_number,
          po_number: formData.po_number,
          grn_number: formData.grn_number,
          grn_quantity: formData.grn_quantity,
          system_grn_date: formData.system_grn_date,
          purchase_by: formData.purchase_by,
          service_invoice_number: formData.service_invoice_number,
          dn_number: formData.dn_number,
          approval_authority: formData.approval_authority,
          total_amount: resolvedArticles.reduce((sum, article) => sum + article.total_amount, 0),
          tax_amount: resolvedArticles.reduce((sum, article) => sum + article.tax_amount, 0),
          discount_amount: resolvedArticles.reduce((sum, article) => sum + article.discount_amount, 0),
          received_quantity: formData.received_quantity,
          remark: formData.remark,
          currency: "INR"
        },
        articles: resolvedArticles.map(article => ({
          transaction_no: formData.transaction_no,
          sku_id: Number(article.sku_id), // guaranteed > 0
          material_type: article.material_type.toLowerCase() === "other" ? (article.material_type_other || article.material_type) : article.material_type,
          item_description: article.item_description.toLowerCase() === "other" ? (article.item_description_other || article.item_description) : article.item_description,
          item_category: article.item_category.toLowerCase() === "other" ? (article.item_category_other || article.item_category) : article.item_category,
          sub_category: article.sub_category.toLowerCase() === "other" ? (article.sub_category_other || article.sub_category) : article.sub_category,
          uom: article.uom,
          packaging_type: article.packaging_type,
          quantity_units: article.quantity_units,
          net_weight: article.net_weight,
          total_weight: article.total_weight,
          batch_number: article.batch_number,
          lot_number: article.lot_number,
          manufacturing_date: article.manufacturing_date,
          expiry_date: article.expiry_date,
          import_date: article.import_date,
          unit_rate: article.unit_rate,
          total_amount: article.total_amount,
          tax_amount: article.tax_amount,
          discount_amount: article.discount_amount,
          currency: article.currency,
          // Issuance fields
          issuance_date: article.issuance_date,
          job_card_no: article.job_card_no,
          issuance_quantity: article.issuance_quantity
        })),
        boxes: boxes.map(box => ({
          transaction_no: formData.transaction_no,
          article_description: box.article,
          box_number: box.box_number,
          net_weight: box.net_weight || 0,
          gross_weight: box.gross_weight || 0,
          lot_number: box.lot_number,
          count: box.count
        }))
      }

      const result = await updateInward(company as Company, transactionId, submissionData)
      toast({
        title: "Success!",
        description: "Inward entry updated successfully!",
      })
      
      // Wait a moment to show the toast before redirecting
      await new Promise(resolve => setTimeout(resolve, 1500))
      
      // Redirect to inward detail page
      router.push(`/${company}/inward/${transactionId}`)
      
    } catch (error) {
      console.error("Error updating inward entry:", error)
      const errorMessage = error instanceof Error ? error.message : String(error)
      toast({
        title: "Error!",
        description: "Error updating inward entry: " + errorMessage,
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  const handlePreview = () => {
    if (!validateForm()) return
  }

  useEffect(() => {
    // Check if only weights changed (to prevent infinite loop with weight update effect)
    const prevArticles = prevArticlesRef.current
    
    // Find which articles changed (excluding weight-only changes)
    const changedArticles: string[] = []
    
    articles.forEach((article, index) => {
      const prev = prevArticles[index]
      if (!prev) {
        // New article added
        changedArticles.push(article.id)
        return
      }

      // Check if this article changed (excluding weight changes)
      const hasNonWeightChanges = (
        article.id !== prev.id ||
        article.item_description !== prev.item_description ||
        article.quantity_units !== prev.quantity_units ||
        article.uom !== prev.uom ||
        article.material_type !== prev.material_type ||
        article.item_category !== prev.item_category ||
        article.sub_category !== prev.sub_category
      )
      
      if (hasNonWeightChanges) {
        changedArticles.push(article.id)
      }
    })
    
    // Check for removed articles
    if (prevArticles.length > articles.length) {
      // Article was removed, regenerate all boxes
      prevArticlesRef.current = articles
      generateBoxes()
      return
    }

    // Update the ref for next comparison
    prevArticlesRef.current = articles

    // Only regenerate boxes for changed articles
    if (changedArticles.length > 0) {
      // If multiple articles changed or article order changed, regenerate all
      if (changedArticles.length > 1 || articles.length !== prevArticles.length) {
        generateBoxes()
      } else {
        // Only one article changed, regenerate boxes only for that article
        generateBoxes(articles, false, changedArticles[0])
      }
    }
  }, [articles, articles.length])

  // Load existing data
  useEffect(() => {
    const loadData = async () => {
      try {
        setLoading(true)
        setError(null)
        const data = await getInwardDetail(company as Company, transactionId)
        setOriginalData(data)
        
        // Populate form data
        setFormData({
          company: data.company,
          transaction_no: data.transaction.transaction_no,
          entry_date: data.transaction.entry_date ? format(new Date(data.transaction.entry_date), "yyyy-MM-dd'T'HH:mm:ss") : "",
          vehicle_number: data.transaction.vehicle_number || "",
          transporter_name: data.transaction.transporter_name || "",
          lr_number: data.transaction.lr_number || "",
          vendor_supplier_name: data.transaction.vendor_supplier_name || "",
          customer_party_name: data.transaction.customer_party_name || "",
          // Custom fields - initialize as empty (will be populated if needed)
          custom_vendor_name: "",
          custom_customer_name: "",
          custom_approval_authority: "",
          source_location: data.transaction.source_location || "",
          destination_location: data.transaction.destination_location || "",
          challan_number: data.transaction.challan_number || "",
          invoice_number: data.transaction.invoice_number || "",
          po_number: data.transaction.po_number || "",
          grn_number: data.transaction.grn_number || "",
          grn_quantity: data.transaction.grn_quantity || 0,
          system_grn_date: data.transaction.system_grn_date || "",
          purchase_by: data.transaction.purchase_by || "",
          bill_submitted_to_account: false,
          grn_remark: "",
          process_type: "",
          service_remarks: "",
          service_invoice_number: data.transaction.service_invoice_number || "",
          dn_number: data.transaction.dn_number || "",
          approval_authority: data.transaction.approval_authority || "",
          received_quantity: data.transaction.received_quantity || 0,
          return_reason_remark: "",
          remark: data.transaction.remark || "",
        })

        // Convert articles
        const convertedArticles: Article[] = data.articles.map((article, index) => ({
          id: article.id?.toString() || (index + 1).toString(),
          sku_id: article.sku_id,
          material_type: article.material_type || "",
          item_category: article.item_category || "",
          sub_category: article.sub_category || "",
          item_description: article.item_description || "",
          quantity_units: article.quantity_units || 0,
          packaging_type: article.packaging_type || 0,
          uom: article.uom || "",
          net_weight: article.net_weight || 0,
          total_weight: article.total_weight || 0,
          batch_number: article.batch_number || "",
          lot_number: article.lot_number || "",
          manufacturing_date: article.manufacturing_date || "",
          expiry_date: article.expiry_date || "",
          import_date: article.import_date || "",
          unit_rate: article.unit_rate || 0,
          total_amount: article.total_amount || 0,
          tax_amount: article.tax_amount || 0,
          discount_amount: article.discount_amount || 0,
          currency: article.currency || "INR",
          // Issuance fields - set defaults if not present in API
          issuance_date: article.issuance_date || "",
          job_card_no: article.job_card_no || "",
          issuance_quantity: article.issuance_quantity || 0,
        }))
        setArticles(convertedArticles)

        // Convert boxes
        const convertedBoxes: Box[] = data.boxes.map((box, index) => ({
          id: box.id?.toString() || (index + 1).toString(),
          box_number: box.box_number,
          article: box.article_description || "",
          net_weight: box.net_weight || 0,
          gross_weight: box.gross_weight || 0,
          lot_number: box.lot_number || "",
          count: box.count || 1,
        }))
        setBoxes(convertedBoxes)

      } catch (err) {
        setError(err instanceof Error ? err.message : "Failed to load inward record")
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [company, transactionId])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 p-2 sm:p-4 lg:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6 w-full">
        <Card>
          <CardContent className="text-center py-12">
            <Loader2 className="mx-auto h-8 w-8 animate-spin" />
            <p className="text-muted-foreground mt-4">Loading inward record...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (error || !originalData) {
    return (
      <div className="min-h-screen bg-gray-50 p-2 sm:p-4 lg:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6 w-full">
        <div className="text-center py-12">
          {error && (
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Record Not Found</h1>
          <p className="text-gray-600 mb-6">The requested inward record with ID "{transactionId}" could not be found.</p>
          <Button asChild>
            <Link href={`/${company}/inward`}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Inward List
            </Link>
          </Button>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 p-2 sm:p-4 lg:p-6 max-w-7xl mx-auto space-y-4 sm:space-y-6 w-full">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm" asChild>
            <Link href={`/${company}/inward/${transactionId}`}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              <span className="hidden sm:inline">Back to Details</span>
              <span className="sm:hidden">Back</span>
            </Link>
          </Button>
          <div>
            <h1 className="text-xl sm:text-2xl lg:text-3xl font-bold tracking-tight">Edit Inward Entry</h1>
            <p className="text-sm sm:text-base text-muted-foreground">Modify existing inward transaction</p>
          </div>
        </div>
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-2">
          <Button variant="outline" onClick={handlePreview} className="flex-1 sm:flex-none">
            <Eye className="mr-2 h-4 w-4" />
            <span className="hidden sm:inline">Preview</span>
            <span className="sm:hidden">View</span>
          </Button>
          <Button onClick={handleSave} disabled={isSubmitting} className="flex-1 sm:flex-none">
            <Save className="mr-2 h-4 w-4" />
            {isSubmitting ? "Updating..." : "Update"}
          </Button>
        </div>
      </div>

      {/* Error Display */}
      {Object.keys(errors).length > 0 && (
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertDescription>
            Please fix the following errors before saving:
            <ul className="mt-2 list-disc list-inside">
              {Object.values(errors).map((error, index) => (
                <li key={index}>{error}</li>
              ))}
            </ul>
          </AlertDescription>
        </Alert>
      )}

      <div className="grid gap-4 sm:gap-6 xl:grid-cols-4">
        {/* Main Form */}
        <div className="xl:col-span-3 space-y-4 sm:space-y-6">
          {/* System Information */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle>System Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div> 
                  <Label htmlFor="company">Company</Label>
                  <Input id="company" value={company} readOnly className="bg-muted" placeholder="Company" />
                </div>
                <div>
                  <Label htmlFor="transaction_no">Transaction Number</Label>
                  <Input id="transaction_no" value={formData.transaction_no} readOnly className="bg-muted" />
                </div>
                <div>
                  <Label htmlFor="entry_date">Entry Date</Label>
                  <Input
                    id="entry_date"
                    type="datetime-local"
                    value={formData.entry_date}
                    readOnly
                    className="bg-muted"
                  />
                </div>
                <div>
                  <Label htmlFor="system_grn_date">System GRN Date</Label>
                  <Input
                    id="system_grn_date"
                    type="date"
                    value={formData.system_grn_date}
                    onChange={(e) => setFormData(prev => ({ ...prev, system_grn_date: e.target.value }))}
                    placeholder="Select GRN date"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Transport Information */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle>Transport Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="vehicle_number">Vehicle Number *</Label>
                  <Input
                    id="vehicle_number"
                    value={formData.vehicle_number}
                    onChange={(e) => setFormData(prev => ({ ...prev, vehicle_number: e.target.value }))}
                    placeholder="MH12AB1234"
                  />
                </div>
                <div>
                  <Label htmlFor="transporter_name">Transporter Name *</Label>
                  <Input
                    id="transporter_name"
                    value={formData.transporter_name}
                    onChange={(e) => setFormData(prev => ({ ...prev, transporter_name: e.target.value }))}
                    placeholder="ABC Transport"
                  />
                </div>
                <div>
                  <Label htmlFor="lr_number">LR Number</Label>
                  <Input
                    id="lr_number"
                    value={formData.lr_number}
                    onChange={(e) => {
                      // Only allow numeric characters
                      const numericValue = e.target.value.replace(/[^0-9]/g, '')
                      setFormData(prev => ({ ...prev, lr_number: numericValue }))
                    }}
                    placeholder="123456789"
                    type="text"
                    inputMode="numeric"
                    pattern="[0-9]*"
                  />
                </div>
                <div>
                  <Label htmlFor="source_location">Source Location</Label>
                  <Input
                    id="source_location"
                    value={formData.source_location}
                    onChange={(e) => setFormData(prev => ({ ...prev, source_location: e.target.value }))}
                    readOnly={formData.vendor_supplier_name !== "Other"}
                    className={formData.vendor_supplier_name !== "Other" ? "bg-muted" : ""}
                    placeholder={formData.vendor_supplier_name === "Other" ? "Enter source location" : "Auto-filled from vendor"}
                  />
                </div>
                <div className="col-span-1 md:col-span-2">
                  <Label htmlFor="destination_location">Destination Location</Label>
                  <Select
                    value={formData.destination_location}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, destination_location: value }))}
                  >
                    <SelectTrigger id="destination_location">
                      <SelectValue placeholder="Select destination" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="W202">W202</SelectItem>
                      <SelectItem value="A185">A185</SelectItem>
                      <SelectItem value="A68">A68</SelectItem>
                      <SelectItem value="F53">F53</SelectItem>
                      <SelectItem value="A101">A101</SelectItem>
                      <SelectItem value="Savla">Savla</SelectItem>
                      <SelectItem value="Rishi">Rishi</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Party Information */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle>Party Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="vendor_supplier_name">Vendor/Supplier Name *</Label>
                  <SearchableSelect
                    value={formData.vendor_supplier_name}
                    onValueChange={async (value) => {
                      setFormData(prev => ({ ...prev, vendor_supplier_name: value }))
                      
                      // If "Other" is selected, don't fetch vendor details
                      if (value === "Other") {
                        return
                      }
                      
                      // Fetch vendor details to get source location and customer
                      if (value && value.trim() !== '') {
                        try {
                          console.log("Fetching details for vendor:", value)
                          const query = new URLSearchParams()
                          query.append('company', company)
                          query.append('vendor_name', value)
                          
                          const apiUrl = `${process.env.NEXT_PUBLIC_API_URL ?? 'http://localhost:8000'}/api/dropdown/vendors?${query.toString()}`
                          
                          const response = await fetch(apiUrl, {
                            method: 'GET',
                            headers: {
                              'Accept': 'application/json',
                              'Content-Type': 'application/json'
                            }
                          })
                          
                          if (response.ok) {
                            const data = await response.json()
                            console.log("Vendor details:", data)
                            
                            // Auto-fill source location
                            const location = data.auto_selection?.resolved_from_vendor?.location || 
                                           data.auto_selection?.location || 
                                           data.location ||
                                           data.source_location ||
                                           ''
                            
                            if (location) {
                              console.log("Auto-filling source location:", location)
                              setFormData(prev => ({ ...prev, source_location: location }))
                            } else {
                              console.log("No location found in vendor data")
                            }
                            
                            // Auto-fill customer/party name
                            const customer = data.auto_selection?.resolved_from_vendor?.customer_name ||
                                           data.auto_selection?.customer_name ||
                                           data.auto_selection?.customer ||
                                           data.customer_name ||
                                           data.customer ||
                                           ''
                            
                            if (customer) {
                              console.log("Auto-filling customer:", customer)
                              setFormData(prev => ({ ...prev, customer_party_name: customer }))
                            } else {
                              console.log("No customer found in vendor data")
                            }
                          }
                        } catch (error) {
                          console.error("Error fetching vendor details:", error)
                          // Don't show error to user, just log it
                        }
                      } else {
                        // Clear source location and customer if vendor is cleared
                        setFormData(prev => ({ ...prev, source_location: "", customer_party_name: "" }))
                      }
                    }}
                    placeholder="Search and select vendor..."
                    options={[...vendorsHook.options, { value: "Other", label: "Other" }]}
                    loading={vendorsHook.loading}
                    error={vendorsHook.error}
                    className={errors.vendor_supplier_name ? "border-red-500" : ""}
                    searchPlaceholder="Type to search vendors..."
                    onSearchChange={setVendorSearch}
                  />
                  {errors.vendor_supplier_name && (
                    <p className="text-sm text-red-500 mt-1">{errors.vendor_supplier_name}</p>
                  )}
                  
                  {/* Show custom vendor fields when "Other" is selected */}
                  {formData.vendor_supplier_name === "Other" && (
                    <div className="mt-2">
                      <div>
                        <Label htmlFor="custom_vendor_name">New vendor *</Label>
                        <Input
                          id="custom_vendor_name"
                          value={formData.custom_vendor_name}
                          onChange={(e) => setFormData(prev => ({ ...prev, custom_vendor_name: e.target.value }))}
                          placeholder="Enter vendor name"
                          className="mt-1"
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div>
                  <Label htmlFor="customer_party_name">Customer/Party Name *</Label>
                  <SearchableSelect
                    value={formData.customer_party_name}
                    onValueChange={(value) => setFormData(prev => ({ ...prev, customer_party_name: value }))}
                    placeholder="Search and select customer..."
                    options={[...customersHook.options, { value: "Other", label: "Other" }]}
                    loading={customersHook.loading}
                    error={customersHook.error}
                    className={errors.customer_party_name ? "border-red-500" : ""}
                    searchPlaceholder="Type to search customers..."
                    onSearchChange={setCustomerSearch}
                  />
                  {errors.customer_party_name && (
                    <p className="text-sm text-red-500 mt-1">{errors.customer_party_name}</p>
                  )}
                  
                  {/* Show custom customer fields when "Other" is selected */}
                  {formData.customer_party_name === "Other" && (
                    <div className="mt-2">
                      <div>
                        <Label htmlFor="custom_customer_name">New customer *</Label>
                        <Input
                          id="custom_customer_name"
                          value={formData.custom_customer_name}
                          onChange={(e) => setFormData(prev => ({ ...prev, custom_customer_name: e.target.value }))}
                          placeholder="Enter customer name"
                          className="mt-1"
                        />
                      </div>
                    </div>
                  )}
                </div>
                <div>
                  <Label htmlFor="purchase_by">Purchase By *</Label>
                  <Input
                    id="purchase_by"
                    value={formData.purchase_by}
                    onChange={(e) => setFormData(prev => ({ ...prev, purchase_by: e.target.value }))}
                    placeholder="Enter purchase by name"
                    className={errors.purchase_by ? "border-red-500" : ""}
                  />
                  {errors.purchase_by && (
                    <p className="text-sm text-red-500 mt-1">{errors.purchase_by}</p>
                  )}
                </div>
                <div>
                  <Label htmlFor="approval_authority">Approval Authority *</Label>
                  <Select value={formData.approval_authority} onValueChange={(value) => setFormData(prev => ({ ...prev, approval_authority: value }))}>
                    <SelectTrigger className={errors.approval_authority ? "border-red-500" : ""}>
                      <SelectValue placeholder="Select approval authority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Vaibhav Kumkar">Vaibhav Kumkar</SelectItem>
                      <SelectItem value="Samal Kumar">Samal Kumar</SelectItem>
                      <SelectItem value="Sumit Baikar">Sumit Baikar</SelectItem>
                      <SelectItem value="Ritesh Dighe">Ritesh Dighe</SelectItem>
                      <SelectItem value="Pankaj Ranga">Pankaj Ranga</SelectItem>
                      <SelectItem value="Vaishali Dhuri">Vaishali Dhuri</SelectItem>
                      <SelectItem value="Himanshu Jadhav">Himanshu Jadhav</SelectItem>
                      <SelectItem value="Suresh Luthra">Suresh Luthra</SelectItem>
                      <SelectItem value="B Hrithik">B Hrithik</SelectItem>
                      <SelectItem value="Suraj Salunkhe">Suraj Salunkhe</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                  {errors.approval_authority && (
                    <p className="text-sm text-red-500 mt-1">{errors.approval_authority}</p>
                  )}
                  
                  {/* Show custom approval authority field when "Other" is selected */}
                  {formData.approval_authority === "Other" && (
                    <div className="mt-2">
                      <div>
                        <Label htmlFor="custom_approval_authority">Custom Approval Authority *</Label>
                        <Input
                          id="custom_approval_authority"
                          value={formData.custom_approval_authority}
                          onChange={(e) => setFormData(prev => ({ ...prev, custom_approval_authority: e.target.value }))}
                          placeholder="Enter approval authority name"
                          className={`mt-1 ${errors.custom_approval_authority ? "border-red-500" : ""}`}
                        />
                        {errors.custom_approval_authority && (
                          <p className="text-sm text-red-500 mt-1">{errors.custom_approval_authority}</p>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Document Information */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle>Document Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="challan_number">Challan Number</Label>
                  <Input
                    id="challan_number"
                    value={formData.challan_number}
                    onChange={(e) => setFormData(prev => ({ ...prev, challan_number: e.target.value }))}
                    placeholder="CH001"
                  />
                </div>
                <div>
                  <Label htmlFor="invoice_number">Invoice Number</Label>
                  <Input
                    id="invoice_number"
                    value={formData.invoice_number}
                    onChange={(e) => setFormData(prev => ({ ...prev, invoice_number: e.target.value }))}
                    placeholder="INV001"
                  />
                </div>
                <div>
                  <Label htmlFor="po_number">PO Number</Label>
                  <Input 
                    id="po_number" 
                    value={formData.po_number} 
                    onChange={(e) => setFormData(prev => ({ ...prev, po_number: e.target.value }))} 
                    placeholder="PO001"
                  />
                </div>
                <div>
                  <Label htmlFor="grn_number">GRN Number</Label>
                  <Input 
                    id="grn_number" 
                    value={formData.grn_number} 
                    onChange={(e) => setFormData(prev => ({ ...prev, grn_number: e.target.value }))} 
                    placeholder="GRN001" 
                  />
                </div>
                <div>
                  <Label htmlFor="grn_quantity">GRN Quantity</Label>
                  <Input
                    id="grn_quantity"
                    type="text"
                    value={grnQuantityDisplay}
                    onChange={(e) => {
                      const inputValue = e.target.value
                      // Allow empty string, numbers, and decimal point
                      if (inputValue === '' || /^\d*\.?\d*$/.test(inputValue)) {
                        setGrnQuantityDisplay(inputValue)
                      }
                    }}
                    onBlur={(e) => {
                      // Convert to float when user finishes typing
                      const value = parseFloat(e.target.value) || 0
                      setFormData(prev => ({ ...prev, grn_quantity: value }))
                      setGrnQuantityDisplay(value.toString())
                    }}
                    onWheel={(e) => e.currentTarget.blur()}
                    placeholder="0.00"
                    inputMode="decimal"
                  />
                </div>
                <div>
                  <Label htmlFor="received_quantity">Received Quantity</Label>
                  <Input
                    id="received_quantity"
                    type="text"
                    value={receivedQuantityDisplay}
                    onChange={(e) => {
                      const inputValue = e.target.value
                      // Allow empty string, numbers, and decimal point
                      if (inputValue === '' || /^\d*\.?\d*$/.test(inputValue)) {
                        setReceivedQuantityDisplay(inputValue)
                      }
                    }}
                    onBlur={(e) => {
                      // Convert to float when user finishes typing
                      const value = parseFloat(e.target.value) || 0
                      setFormData(prev => ({ ...prev, received_quantity: value }))
                      setReceivedQuantityDisplay(value.toString())
                    }}
                    onWheel={(e) => e.currentTarget.blur()}
                    placeholder="0.00"
                    inputMode="decimal"
                  />
                </div>
                <div>
                  <Label htmlFor="dn_number">Delivery Note Number</Label>
                  <Input 
                    id="dn_number" 
                    value={formData.dn_number} 
                    onChange={(e) => setFormData(prev => ({ ...prev, dn_number: e.target.value }))} 
                    placeholder="DN001" 
                  />
                </div>
                <div>
                  <Label htmlFor="service_invoice_number">Service Invoice Number</Label>
                  <Input
                    id="service_invoice_number"
                    value={formData.service_invoice_number}
                    onChange={(e) => setFormData(prev => ({ ...prev, service_invoice_number: e.target.value }))}
                    placeholder="SRV001"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Remarks Section */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle>Remarks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="remark">General Remarks</Label>
                <Textarea
                  id="remark"
                  value={formData.remark}
                  onChange={(e) => setFormData(prev => ({ ...prev, remark: e.target.value }))}
                  placeholder="Remark regarding Short Quantity, Damaged Packaging, Moisture Content High, Mismatched Batch No., Infestation Detected, Temperature Deviation, etc."
                  className="min-h-[100px]"
                />
              </div>
            </CardContent>
          </Card>

          {/* Articles Section */}
          <Card className="w-full">
            <CardHeader>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <CardTitle>Articles ({articles.length})</CardTitle>
                <Button onClick={addArticle} size="sm" className="w-full sm:w-auto">
                  <Plus className="mr-2 h-4 w-4" />
                  Add Article
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {articles.map((article, index) => (
                <div key={article.id} className="border rounded-lg p-4 space-y-4">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium">Article {index + 1}</h4>
                    <div className="flex items-center gap-2">
                      {article.sku_id && (
                        <Badge variant="outline" className="text-xs">
                          SKU: {article.sku_id}
                        </Badge>
                      )}
                      {articles.length > 1 && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => removeArticle(article.id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {/* Material Type */}
                    <div>
                      <Label htmlFor={`material_type_${article.id}`}>Material Type *</Label>
                      <MaterialTypeDropdown
                        value={article.material_type}
                        onValueChange={(value) => {
                          console.log("Material Type selected:", value, "for article:", article.id)
                          // Update the article with new material type and clear dependent fields in a single operation
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return {
                                ...art,
                                material_type: value,
                                item_category: "",
                                sub_category: "",
                                item_description: "",
                                sku_id: null
                              }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                        company={company as Company}
                        error={errors[`article_${index}_material_type`]}
                        otherValue={article.material_type_other || ""}
                        onOtherValueChange={(value) => {
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return { ...art, material_type_other: value }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                      />
                      {errors[`article_${index}_material_type`] && (
                        <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_material_type`]}</p>
                      )}
                    </div>

                    {/* Item Category */}
                    <div>
                      <Label htmlFor={`item_category_${article.id}`}>Item Category *</Label>
                      <ItemCategoryDropdown
                        value={article.item_category}
                        onValueChange={(value) => {
                          console.log("Item Category selected:", value, "for article:", article.id)
                          // Update the article with new category and clear dependent fields in a single operation
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return {
                                ...art,
                                item_category: value,
                                sub_category: "",
                                item_description: "",
                                sku_id: null
                              }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                        company={company as Company}
                        materialType={article.material_type}
                        error={errors[`article_${index}_category`]}
                        disabled={!article.material_type}
                        otherValue={article.item_category_other || ""}
                        onOtherValueChange={(value) => {
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return { ...art, item_category_other: value }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                      />
                      {errors[`article_${index}_category`] && (
                        <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_category`]}</p>
                      )}
                    </div>

                    {/* Sub Category */}
                    <div>
                      <Label htmlFor={`sub_category_${article.id}`}>Sub Category *</Label>
                      <SubCategoryDropdown
                        articleId={article.id}
                        categoryId={article.item_category}
                        value={article.sub_category}
                        onValueChange={(value) => {
                          console.log("Sub Category selected:", value, "for article:", article.id)
                          // Update the article with new sub category and clear dependent fields in a single operation
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return {
                                ...art,
                                sub_category: value,
                                item_description: "",
                                sku_id: null
                              }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                        company={company as Company}
                        error={errors[`article_${index}_sub_category`]}
                        disabled={!article.material_type || !article.item_category}
                        materialType={article.material_type}
                        otherValue={article.sub_category_other || ""}
                        onOtherValueChange={(value) => {
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return { ...art, sub_category_other: value }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                      />
                      {errors[`article_${index}_sub_category`] && (
                        <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_sub_category`]}</p>
                      )}
                    </div>

                    {/* Item Description */}
                    <div>
                      <Label htmlFor={`item_description_${article.id}`}>Item Description *</Label>
                      <ItemDescriptionDropdown
                        articleId={article.id}
                        categoryId={article.item_category}
                        subCategoryId={article.sub_category}
                        materialType={article.material_type}
                        value={article.item_description}
                        onValueChange={(value) => {
                          console.log("Item Description selected:", value, "for article:", article.id)
                          // Update the article with new item description in a single operation
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return {
                                ...art,
                                item_description: value
                              }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                        company={company as Company}
                        error={errors[`article_${index}_description`]}
                        updateArticle={updateArticle}
                        disabled={!article.material_type || !article.item_category || !article.sub_category}
                        otherValue={article.item_description_other || ""}
                        onOtherValueChange={(value) => {
                          const updatedArticles = articles.map((art) => {
                            if (art.id === article.id) {
                              return { ...art, item_description_other: value }
                            }
                            return art
                          })
                          setArticles(updatedArticles)
                        }}
                      />
                      {errors[`article_${index}_description`] && (
                        <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_description`]}</p>
                      )}
                    </div>

                    {/* Quantity Units */}
                    <div>
                      <Label htmlFor={`quantity_units_${article.id}`}>Quantity Units *</Label>
                      <Input
                        id={`quantity_units_${article.id}`}
                        type="number"
                        min="0"
                        value={article.quantity_units}
                        onChange={(e) => updateArticle(article.id, "quantity_units", Number(e.target.value))}
                        onWheel={(e) => e.currentTarget.blur()}
                        className={quantityWarnings[article.id] ? "border-yellow-500" : ""}
                      />
                      {quantityWarnings[article.id] && (
                        <p className="text-sm text-yellow-600 mt-1 flex items-center gap-1">
                          <AlertCircle className="h-3 w-3" />
                          {quantityWarnings[article.id]}
                        </p>
                      )}
                    </div>

                    {/* Pack Size */}
                    <div>
                      <Label htmlFor={`packaging_type_${article.id}`}>Pack size ( weights )</Label>
                      <Input
                        id={`packaging_type_${article.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        value={article.packaging_type}
                        onChange={(e) => updateArticle(article.id, "packaging_type", parseFloat(e.target.value) || 0)}
                        onWheel={(e) => e.currentTarget.blur()}
                        placeholder="10.5"
                      />
                    </div>

                    {/* UOM */}
                    <div>
                      <Label htmlFor={`uom_${article.id}`}>UOM *</Label>
                      <Select 
                        value={article.uom} 
                        onValueChange={(value) => updateArticle(article.id, "uom", value)}
                      >
                        <SelectTrigger id={`uom_${article.id}`}>
                          <SelectValue placeholder="Select UOM" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="BAG">BAG</SelectItem>
                          <SelectItem value="BOX">BOX</SelectItem>
                          <SelectItem value="CARTON">CARTON</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    {/* Net Weight */}
                    <div>
                      <Label htmlFor={`net_weight_${article.id}`}>Net Weight *</Label>
                      <Input
                        id={`net_weight_${article.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        value={article.net_weight}
                        onChange={(e) => updateArticle(article.id, "net_weight", Number(e.target.value))}
                        onWheel={(e) => e.currentTarget.blur()}
                      />
                    </div>

                    {/* Gross Weight */}
                    <div>
                      <Label htmlFor={`gross_weight_${article.id}`}>Gross Weight *</Label>
                      <Input
                        id={`gross_weight_${article.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        value={article.total_weight}
                        onChange={(e) => updateArticle(article.id, "total_weight", Number(e.target.value))}
                        onWheel={(e) => e.currentTarget.blur()}
                        className={errors[`article_${index}_total_weight`] ? "border-red-500" : ""}
                      />
                      {errors[`article_${index}_total_weight`] && (
                        <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_total_weight`]}</p>
                      )}
                      {article.net_weight > 0 && article.total_weight > 0 && article.total_weight <= article.net_weight && (
                        <p className="text-sm text-orange-500 mt-1">⚠️ Gross weight should be greater than net weight ({article.net_weight} kg)</p>
                      )}
                    </div>

                    {/* Lot Number */}
                    <div>
                      <Label htmlFor={`lot_number_${article.id}`}>Lot Number</Label>
                      <Input
                        id={`lot_number_${article.id}`}
                        value={article.lot_number}
                        onChange={(e) => updateArticle(article.id, "lot_number", e.target.value)}
                        placeholder="LOT-2024-001"
                      />
                    </div>

                    {/* Manufacturing Date */}
                    <div>
                      <Label htmlFor={`manufacturing_date_${article.id}`}>Manufacturing Date</Label>
                      <Input
                        id={`manufacturing_date_${article.id}`}
                        type="date"
                        value={article.manufacturing_date}
                        onChange={(e) => updateArticle(article.id, "manufacturing_date", e.target.value)}
                      />
                    </div>

                    {/* Expiry Date */}
                    <div>
                      <Label htmlFor={`expiry_date_${article.id}`}>Expiry Date</Label>
                      <Input
                        id={`expiry_date_${article.id}`}
                        type="date"
                        value={article.expiry_date}
                        onChange={(e) => updateArticle(article.id, "expiry_date", e.target.value)}
                      />
                    </div>

                    {/* Import Date */}
                    <div>
                      <Label htmlFor={`import_date_${article.id}`}>Import Date</Label>
                      <Input
                        id={`import_date_${article.id}`}
                        type="date"
                        value={article.import_date}
                        onChange={(e) => updateArticle(article.id, "import_date", e.target.value)}
                      />
                    </div>

                    {/* Unit Rate */}
                    {/* <div>
                      <Label htmlFor={`unit_rate_${article.id}`}>Unit Rate</Label>
                      <Input
                        id={`unit_rate_${article.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        value={article.unit_rate}
                        onChange={(e) => updateArticle(article.id, "unit_rate", Number(e.target.value))}
                        onWheel={(e) => e.currentTarget.blur()}
                      />
                    </div> */}

                    {/* Total Amount */}
                    {/* <div>
                      <Label htmlFor={`total_amount_${article.id}`}>Total Amount</Label>
                      <Input
                        id={`total_amount_${article.id}`}
                        type="number"
                        step="0.01"
                        value={article.total_amount}
                        readOnly
                        className="bg-muted"
                      />
                    </div> */}

                    {/* Tax Amount */}
                    {/* <div>
                      <Label htmlFor={`tax_amount_${article.id}`}>Tax Amount</Label>
                      <Input
                        id={`tax_amount_${article.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        value={article.tax_amount}
                        onChange={(e) => updateArticle(article.id, "tax_amount", Number(e.target.value))}
                        onWheel={(e) => e.currentTarget.blur()}
                      />
                    </div> */}

                    {/* Discount Amount */}
                    {/* <div>
                      <Label htmlFor={`discount_amount_${article.id}`}>Discount Amount</Label>
                      <Input
                        id={`discount_amount_${article.id}`}
                        type="number"
                        step="0.01"
                        min="0"
                        value={article.discount_amount}
                        onChange={(e) => updateArticle(article.id, "discount_amount", Number(e.target.value))}
                        onWheel={(e) => e.currentTarget.blur()}
                      />
                    </div> */}

                    {/* Currency */}
                    {/* <div>
                      <Label htmlFor={`currency_${article.id}`}>Currency</Label>
                      <Select 
                        value={article.currency} 
                        onValueChange={(value) => updateArticle(article.id, "currency", value)}
                      >
                        <SelectTrigger id={`currency_${article.id}`}>
                          <SelectValue placeholder="Select currency" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="INR">INR</SelectItem>
                          <SelectItem value="USD">USD</SelectItem>
                          <SelectItem value="EUR">EUR</SelectItem>
                        </SelectContent>
                      </Select>
                    </div> */}
                  </div>

                  {/* Issuance Section */}
                  <div className="border-t pt-4">
                    <h5 className="font-medium mb-4 text-blue-600">Issuance Details</h5>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {/* Issuance Date */}
                      <div>
                        <Label htmlFor={`issuance_date_${article.id}`}>Issuance Date</Label>
                        <Input
                          id={`issuance_date_${article.id}`}
                          type="date"
                          value={article.issuance_date}
                          onChange={(e) => updateArticle(article.id, "issuance_date", e.target.value)}
                          className={errors[`article_${index}_issuance_date`] ? "border-red-500" : ""}
                        />
                        {errors[`article_${index}_issuance_date`] && (
                          <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_issuance_date`]}</p>
                        )}
                      </div>

                      {/* Job Card No */}
                      <div>
                        <Label htmlFor={`job_card_no_${article.id}`}>Job Card No</Label>
                        <Input
                          id={`job_card_no_${article.id}`}
                          type="text"
                          value={article.job_card_no}
                          onChange={(e) => updateArticle(article.id, "job_card_no", e.target.value)}
                          placeholder="Enter job card number"
                          className={errors[`article_${index}_job_card_no`] ? "border-red-500" : ""}
                        />
                        {errors[`article_${index}_job_card_no`] && (
                          <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_job_card_no`]}</p>
                        )}
                      </div>

                      {/* Issuance Quantity */}
                      <div>
                        <Label htmlFor={`issuance_quantity_${article.id}`}>Issuance Quantity</Label>
                        <Input
                          id={`issuance_quantity_${article.id}`}
                          type="text"
                          value={issuanceQuantityDisplays[article.id] || ""}
                          onChange={(e) => {
                            const inputValue = e.target.value
                            // Allow empty string, numbers, and decimal point
                            if (inputValue === '' || /^\d*\.?\d*$/.test(inputValue)) {
                              setIssuanceQuantityDisplays(prev => ({
                                ...prev,
                                [article.id]: inputValue
                              }))
                            }
                          }}
                          onBlur={(e) => {
                            // Convert to float when user finishes typing
                            const value = parseFloat(e.target.value) || 0
                            updateArticle(article.id, "issuance_quantity", value)
                            setIssuanceQuantityDisplays(prev => ({
                              ...prev,
                              [article.id]: value.toString()
                            }))
                          }}
                          onWheel={(e) => e.currentTarget.blur()}
                          placeholder="0.00"
                          inputMode="decimal"
                          className={errors[`article_${index}_issuance_quantity`] ? "border-red-500" : ""}
                        />
                        {errors[`article_${index}_issuance_quantity`] && (
                          <p className="text-sm text-red-500 mt-1">{errors[`article_${index}_issuance_quantity`]}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Box Management */}
          <Card className="w-full">
            <CardHeader>
              <CardTitle>Box Management ({boxes.length} boxes)</CardTitle>
            </CardHeader>
            <CardContent>
              {boxes.length > 0 ? (
                <div className="space-y-4">
                  <div className="space-y-3">
                    <h4 className="font-medium text-lg">Per-Article Summary</h4>
                    <div className="grid gap-4">
                      {Object.entries(getArticleBoxStats()).map(([articleId, stats]) => (
                        <div key={articleId} className="p-4 border rounded-lg bg-gray-50">
                          <div className="flex items-center justify-between mb-3">
                            <h5 className="font-medium text-sm">{stats.articleName}</h5>
                            <Badge variant="outline">{stats.boxes} boxes</Badge>
                          </div>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="text-gray-600">Total Net Weight:</span>
                              <span className="ml-2 font-medium">{stats.netWeight.toFixed(2)} kg</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Total Gross Weight:</span>
                              <span className="ml-2 font-medium">{stats.grossWeight.toFixed(2)} kg</span>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="overflow-x-auto -mx-2 sm:mx-0">
                    <div className="min-w-[600px] px-2 sm:px-0">
                      <table className="w-full border-collapse border border-gray-300">
                        <thead>
          <tr className="bg-gray-50">
            <th className="border border-gray-300 px-4 py-2 text-left font-medium">Box Number</th>
            <th className="border border-gray-300 px-4 py-2 text-left font-medium">Article Name</th>
            <th className="border border-gray-300 px-4 py-2 text-left font-medium">Lot Number</th>
            <th className="border border-gray-300 px-4 py-2 text-left font-medium">Count</th>
            <th className="border border-gray-300 px-4 py-2 text-left font-medium">Net Weight (kg) (Optional)</th>
            <th className="border border-gray-300 px-4 py-2 text-left font-medium">Gross Weight (kg) (Optional)</th>
            <th className="border border-gray-300 px-4 py-2 text-left font-medium">Actions</th>
          </tr>
                        </thead>
                        <tbody>
                          {boxes.map((box) => (
                            <tr key={box.id} className="hover:bg-gray-50">
                              <td className="border border-gray-300 px-4 py-2">
                                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
                                  <span className="font-medium text-sm">{box.box_number}</span>
                                </div>
                              </td>
                              <td className="border border-gray-300 px-4 py-2">
                                <span className="text-sm font-medium">{box.article}</span>
                              </td>
                              <td className="border border-gray-300 px-4 py-2">
                                <span className="text-sm">{box.lot_number || "-"}</span>
                              </td>
                              <td className="border border-gray-300 px-4 py-2">
                                {(() => {
                                  const associatedArticle = articles.find(art => art.item_description === box.article)
                                  const isPM = associatedArticle?.material_type?.toUpperCase() === "PM"
                                  const isBag = associatedArticle?.uom?.toUpperCase() === "BAG"
                                  const isCountEditable = isPM || isBag
                                  return (
                                    <Input
                                      key={`count-${box.id}-${associatedArticle?.material_type || 'none'}-${associatedArticle?.uom || 'none'}`}
                                      type="number"
                                      min="1"
                                      value={box.count}
                                      onChange={(e) => updateBox(box.id, "count", Math.max(1, Number(e.target.value) || 1))}
                                      onBlur={(e) => {
                                        if (!e.target.value || Number(e.target.value) < 1) {
                                          updateBox(box.id, "count", 1)
                                        }
                                      }}
                                      className="w-20 no-spinner"
                                      disabled={!isCountEditable}
                                      title={isCountEditable ? "Edit count" : "Count is locked (only editable for PM material type or BAG UOM)"}
                                    />
                                  )
                                })()}
                              </td>
                              <td className="border border-gray-300 px-4 py-2">
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  value={box.net_weight || ""}
                                  onChange={(e) => updateBox(box.id, "net_weight", e.target.value)}
                                  onWheel={(e) => e.currentTarget.blur()}
                                  placeholder="0"
                                  className="w-full"
                                />
                              </td>
                              <td className="border border-gray-300 px-4 py-2">
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  value={box.gross_weight || ""}
                                  onChange={(e) => updateBox(box.id, "gross_weight", e.target.value)}
                                  onWheel={(e) => e.currentTarget.blur()}
                                  placeholder="0"
                                  className="w-full"
                                />
                              </td>
                              <td className="border border-gray-300 px-4 py-2">
                                <div className="flex gap-2">
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handlePrintBox(box)}
                                    disabled={printingBoxes.has(box.box_number)}
                                    className="flex items-center gap-1"
                                  >
                                    <Printer className="h-3 w-3" />
                                    {printingBoxes.has(box.box_number) ? "Printing..." : "Print"}
                                  </Button>
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => handleDeleteBox(box)}
                                    className="flex items-center gap-1 text-red-600 hover:text-red-700 hover:bg-red-50 border-red-200 hover:border-red-300"
                                    title="Delete box"
                                  >
                                    <X className="h-3 w-3" />
                                  </Button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <div className="text-center">
                      <p className="text-sm text-blue-700 font-medium">Total Boxes</p>
                      <p className="text-2xl font-bold text-blue-900">{boxes.length}</p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-blue-700 font-medium">Total Net Weight</p>
                      <p className="text-2xl font-bold text-blue-900">
                        {boxes.reduce((sum, box) => sum + box.net_weight, 0).toFixed(2)} kg
                      </p>
                    </div>
                    <div className="text-center">
                      <p className="text-sm text-blue-700 font-medium">Total Gross Weight</p>
                      <p className="text-2xl font-bold text-blue-900">
                        {boxes.reduce((sum, box) => sum + box.gross_weight, 0).toFixed(2)} kg
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <p>No boxes available for this record.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-3">
          <Card className="w-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Quick Box Preview</CardTitle>
            </CardHeader>
            <CardContent className="pt-2">
              {boxes.length > 0 ? (
                <div className="space-y-2">
                  {/* Total Statistics */}
                  <div className="grid grid-cols-1 gap-2 p-2 bg-blue-50 rounded border">
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-blue-700">Total Boxes:</span>
                      <span className="text-sm font-bold text-blue-900">{boxes.length}</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-blue-700">Net Weight:</span>
                      <span className="text-sm font-bold text-blue-900">
                        {boxes.reduce((sum, box) => sum + box.net_weight, 0).toFixed(2)} kg
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-blue-700">Gross Weight:</span>
                      <span className="text-sm font-bold text-blue-900">
                        {boxes.reduce((sum, box) => sum + box.gross_weight, 0).toFixed(2)} kg
                      </span>
                    </div>
                  </div>
                </div>
              ) : (
                <p className="text-xs text-muted-foreground text-center">No boxes</p>
              )}
            </CardContent>
          </Card>

          <Card className="w-full">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm">Summary</CardTitle>
            </CardHeader>
            <CardContent className="pt-2 space-y-2">
              <div className="flex justify-between">
                <span className="text-xs text-muted-foreground">Articles:</span>
                <span className="text-sm font-medium">{articles.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs text-muted-foreground">Quantity:</span>
                <span className="text-sm font-medium">
                  {articles.reduce((sum, article) => sum + article.quantity_units, 0)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-xs text-muted-foreground">Boxes:</span>
                <span className="text-sm font-medium">{boxes.length}</span>
              </div>
              <Separator className="my-2" />
              <div className="flex justify-between">
                <span className="text-xs text-muted-foreground">Amount:</span>
                <span className="text-sm font-bold">
                  ₹{articles.reduce((sum, article) => sum + article.total_amount, 0).toFixed(2)}
                </span>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
