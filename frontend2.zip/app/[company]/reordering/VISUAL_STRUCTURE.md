# RTV Module - Visual Structure

## 📊 Module Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    RTV MODULE STRUCTURE                      │
└─────────────────────────────────────────────────────────────┘

                    ┌─────────────────────┐
                    │   RTV Dashboard     │
                    │  /reordering        │
                    └──────────┬──────────┘
                               │
               ┌───────────────┼───────────────┐
               │               │               │
               ▼               ▼               ▼
      ┌────────────┐  ┌────────────┐  ┌────────────┐
      │  Statistics│  │   Search   │  │   Filters  │
      │   Cards    │  │    Bar     │  │  Buttons   │
      └────────────┘  └────────────┘  └────────────┘
               │               │               │
               └───────────────┼───────────────┘
                               ▼
                      ┌────────────────┐
                      │  RTV Records   │
                      │     Table      │
                      └────────┬───────┘
                               │
               ┌───────────────┼───────────────┐
               │               │               │
               ▼               ▼               ▼
      ┌────────────┐  ┌────────────┐  ┌────────────┐
      │   Create   │  │    View    │  │   Export   │
      │ RTV Button │  │  Details   │  │   Action   │
      └────────────┘  └────────────┘  └────────────┘
```

## 🆕 Create RTV Flow

```
┌─────────────────────────────────────────────────────────────┐
│              CREATE RTV FORM STRUCTURE                       │
└─────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────┐
    │                   HEADER                          │
    │  [Back Button]  Create RTV  |  RTV-NUMBER       │
    └──────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────┐
    │              LEFT COLUMN (Main)                   │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │        RTV DETAILS CARD                     │ │
    │  │  ┌────────────┐  ┌────────────┐           │ │
    │  │  │   Vendor   │  │  RTV Type  │           │ │
    │  │  └────────────┘  └────────────┘           │ │
    │  │  ┌────────────┐  ┌────────────┐           │ │
    │  │  │    GRN     │  │  DC Number │           │ │
    │  │  └────────────┘  └────────────┘           │ │
    │  │  ┌──────────────────────────────┐         │ │
    │  │  │         Notes                 │         │ │
    │  │  └──────────────────────────────┘         │ │
    │  └────────────────────────────────────────────┘ │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │        QR SCANNER CARD                      │ │
    │  │                                              │ │
    │  │         ┌──────────────────┐                │ │
    │  │         │   📷 Camera      │                │ │
    │  │         │   QR Scanner     │                │ │
    │  │         │   Preview        │                │ │
    │  │         └──────────────────┘                │ │
    │  │         [Start Scanning]                    │ │
    │  └────────────────────────────────────────────┘ │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │     SCANNED BOXES LIST CARD                 │ │
    │  │                                              │ │
    │  │  ┌──────────────────────────────────────┐  │ │
    │  │  │ Box #1 | RM                          │  │ │
    │  │  │ Wheat Flour - BATCH-001              │  │ │
    │  │  │ Qty: 50 KG | Weight: 50.5 KG        │  │ │
    │  │  │ ┌─────────────────┐ ┌─────────────┐ │  │ │
    │  │  │ │ Reason (*)      │ │ Value (*)   │ │  │ │
    │  │  │ │ [Textarea]      │ │ [Number]    │ │  │ │
    │  │  │ └─────────────────┘ └─────────────┘ │  │ │
    │  │  │                           [🗑️ Remove]│  │ │
    │  │  └──────────────────────────────────────┘  │ │
    │  │                                              │ │
    │  │  ┌──────────────────────────────────────┐  │ │
    │  │  │ Box #2 | PM                          │  │ │
    │  │  │ [Similar structure...]                │  │ │
    │  │  └──────────────────────────────────────┘  │ │
    │  └────────────────────────────────────────────┘ │
    └──────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────┐
    │        RIGHT COLUMN (Summary - Sticky)            │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │        RTV SUMMARY CARD                     │ │
    │  │                                              │ │
    │  │  RTV Number:        RTV202410...           │ │
    │  │  Vendor:            ABC Suppliers          │ │
    │  │  RTV Type:          Quality Issue          │ │
    │  │  ─────────────────────────────────────     │ │
    │  │  📦 Total Boxes:           5               │ │
    │  │  Total Quantity:           250             │ │
    │  │  Total Value:         ₹15,000              │ │
    │  │  ─────────────────────────────────────     │ │
    │  │                                              │ │
    │  │  [✅ Create RTV ]                           │ │
    │  │  [    Cancel    ]                           │ │
    │  │                                              │ │
    │  │  STATUS CHECKLIST:                          │ │
    │  │  ✓ Vendor Selected                          │ │
    │  │  ✓ RTV Type Selected                        │ │
    │  │  ✓ Boxes Scanned                            │ │
    │  │  ✗ All Details Filled                       │ │
    │  └────────────────────────────────────────────┘ │
    └──────────────────────────────────────────────────┘
```

## 👁️ View RTV Details

```
┌─────────────────────────────────────────────────────────────┐
│              VIEW RTV DETAILS LAYOUT                         │
└─────────────────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────┐
    │                   HEADER                          │
    │  [Back]  RTV Details - RTV202410211530           │
    │  [Status Badge] [Export] [Print]                 │
    └──────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────┐
    │              LEFT COLUMN (Main)                   │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │     RTV INFORMATION CARD                    │ │
    │  │                                              │ │
    │  │  RTV Number:    RTV202410211530            │ │
    │  │  Status:        [Pending Badge]            │ │
    │  │  Vendor:        ABC Suppliers Ltd          │ │
    │  │  RTV Type:      Quality Issue              │ │
    │  │  Material:      [RM Badge]                 │ │
    │  │  Total Value:   ₹15,000                    │ │
    │  │  GRN Ref:       GRN-2024-001               │ │
    │  │  Notes:         Quality not meeting...     │ │
    │  └────────────────────────────────────────────┘ │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │     ITEMS LIST CARD (5 items)               │ │
    │  │                                              │ │
    │  │  ┌──────────────────────────────────────┐  │ │
    │  │  │ Item #1 | RM-001                     │  │ │
    │  │  │ Wheat Flour               ₹2,500    │  │ │
    │  │  │ ───────────────────────────────────  │  │ │
    │  │  │ Batch: BATCH-001  |  Qty: 50 KG     │  │ │
    │  │  │ Weight: 50.5 KG   |  TX: CONS...    │  │ │
    │  │  │ Reason: Moisture content too high    │  │ │
    │  │  └──────────────────────────────────────┘  │ │
    │  │                                              │ │
    │  │  [Similar cards for other items...]         │ │
    │  └────────────────────────────────────────────┘ │
    └──────────────────────────────────────────────────┘

    ┌──────────────────────────────────────────────────┐
    │        RIGHT COLUMN (Sidebar - Sticky)            │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │        TIMELINE CARD                        │ │
    │  │                                              │ │
    │  │  📄 Created                                 │ │
    │  │     Oct 15, 2024                           │ │
    │  │     By John Doe                            │ │
    │  │  ─────────────────                         │ │
    │  │  ✅ Approved                                │ │
    │  │     Oct 16, 2024                           │ │
    │  │     By Manager Admin                       │ │
    │  └────────────────────────────────────────────┘ │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │        SUMMARY CARD                         │ │
    │  │                                              │ │
    │  │  Total Items:           5                  │ │
    │  │  Total Quantity:        250                │ │
    │  │  Total Value:      ₹15,000                 │ │
    │  └────────────────────────────────────────────┘ │
    │                                                    │
    │  ┌────────────────────────────────────────────┐ │
    │  │        ACTIONS CARD (if pending)            │ │
    │  │                                              │ │
    │  │  [✅ Approve RTV]                           │ │
    │  │  [❌ Reject RTV]                            │ │
    │  └────────────────────────────────────────────┘ │
    └──────────────────────────────────────────────────┘
```

## 🔄 QR Scanner Flow

```
┌─────────────────────────────────────────────────────────────┐
│                QR SCANNER WORKFLOW                           │
└─────────────────────────────────────────────────────────────┘

          [Start Scanning Button Clicked]
                      │
                      ▼
          ┌───────────────────────┐
          │  Open QR Scanner      │
          │  Request Camera       │
          └───────────┬───────────┘
                      │
                      ▼
          ┌───────────────────────┐
          │  Camera Preview       │
          │  Real-time Scanning   │
          └───────────┬───────────┘
                      │
                      ▼
          ┌───────────────────────┐
          │  QR Code Detected     │
          │  Parse JSON Data      │
          └───────────┬───────────┘
                      │
                      ▼
          ┌───────────────────────┐
          │  Check Duplicate?     │
          └───────────┬───────────┘
                      │
           ┌──────────┴──────────┐
           │                     │
           ▼ YES                 ▼ NO
    [❌ Show Error]      [✅ Add to List]
    [Toast Message]       [Update Counter]
                              │
                              ▼
                      [Close Scanner]
                      [Show Success Toast]
```

## 📋 Data Flow Diagram

```
┌─────────────────────────────────────────────────────────────┐
│                   DATA FLOW DIAGRAM                          │
└─────────────────────────────────────────────────────────────┘

    USER INTERFACE              COMPONENT STATE           BACKEND (TODO)
    ──────────────              ────────────────          ──────────────

    [Select Vendor]
           │
           ▼
    ┌──────────────┐
    │  Vendor Code  │ ────────────────────────▶ [Vendor API]
    │  Vendor Name  │                                │
    └──────────────┘                                │
           │                                         ▼
           │                               ┌──────────────────┐
           │                               │ Validate Vendor  │
           │                               └──────────────────┘
           ▼
    [Select RTV Type]
           │
           ▼
    ┌──────────────┐
    │   RTV Type    │
    └──────────────┘
           │
           ▼
    [Scan QR Codes]
           │
           ▼
    ┌──────────────────┐
    │   QR Code Data    │
    └──────────┬────────┘
               │
               ▼
    ┌──────────────────┐
    │  Scanned Boxes   │ ◀────── [Check Duplicate]
    │    Array         │
    └──────────┬────────┘
               │
               ▼
    [Fill Reason & Value]
               │
               ▼
    ┌──────────────────┐
    │   RTV Summary    │
    │   Calculate      │
    │   Totals         │
    └──────────┬────────┘
               │
               ▼
    [Submit RTV]
               │
               ▼
    ┌──────────────────┐
    │   RTV Form Data   │ ────────────────────▶ [Create RTV API]
    └──────────────────┘                               │
               │                                        ▼
               │                              ┌──────────────────┐
               │                              │ Validate & Save  │
               │                              │ Generate RTV ID  │
               │                              └────────┬─────────┘
               │                                       │
               │                                       ▼
               │                              ┌──────────────────┐
               │                              │ Return Response  │
               │                              └────────┬─────────┘
               │                                       │
               ◀───────────────────────────────────────┘
               │
               ▼
    [Show Success Toast]
               │
               ▼
    [Redirect to Dashboard]
```

## 🎯 Component Hierarchy

```
┌─────────────────────────────────────────────────────────────┐
│              COMPONENT HIERARCHY                             │
└─────────────────────────────────────────────────────────────┘

ReorderingPage (Dashboard)
├── Card (Statistics)
│   ├── Total RTVs
│   ├── Pending Count
│   ├── Approved Count
│   ├── Completed Count
│   └── Total Value
├── Card (RTV Records)
│   ├── Search Input
│   ├── Status Filter Buttons
│   └── Table
│       ├── Table Header
│       └── Table Body
│           └── Table Rows
│               ├── RTV Number
│               ├── Vendor
│               ├── Type Badge
│               ├── Material Badge
│               ├── Items Count
│               ├── Value
│               ├── Status Badge
│               ├── Date
│               └── View Button

CreateRTVPage
├── Header
│   ├── Back Button
│   ├── Title
│   └── RTV Number Badge
├── Left Column (2/3)
│   ├── Card (RTV Details)
│   │   ├── Vendor SearchableSelect
│   │   ├── RTV Type Select
│   │   ├── GRN Reference Input
│   │   ├── DC Number Input
│   │   └── Notes Textarea
│   ├── Card (QR Scanner)
│   │   ├── Scanner Preview / Placeholder
│   │   └── Start/Stop Buttons
│   └── Card (Scanned Boxes)
│       └── Box Cards (Array)
│           ├── Box Info Display
│           ├── Reason Textarea
│           ├── Value Input
│           └── Remove Button
└── Right Column (1/3 - Sticky)
    └── Card (Summary)
        ├── RTV Info
        ├── Totals
        ├── Status Checklist
        └── Action Buttons

ViewRTVPage
├── Header
│   ├── Back Button
│   ├── Title
│   ├── Status Badge
│   └── Action Buttons
├── Left Column (2/3)
│   ├── Card (RTV Information)
│   │   └── All RTV Fields
│   └── Card (Items List)
│       └── Item Cards (Array)
└── Right Column (1/3 - Sticky)
    ├── Card (Timeline)
    │   ├── Created Event
    │   └── Approved Event
    ├── Card (Summary)
    │   ├── Total Items
    │   ├── Total Quantity
    │   └── Total Value
    └── Card (Actions) [if pending]
        ├── Approve Button
        └── Reject Button
```

---

**This visual guide shows the complete structure and flow of the RTV module!**
